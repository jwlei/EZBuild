# 2.1.0
Added: Modifier+Scroll to change snap location (Default: LeftAlt)
Changed: Default modifier for scrolling piece selection to LeftCtrl

# 2.0.1
Extended index to fix bug where you could not pipette / eyedrop pieces in the last columns.

# 2.0.0
Mistlands port

# 1.1.5
Added: Option to prefer 2H or 1H axes when pipetting

# 1.1.4
Added: Pipette for axes now also includes battleaxes. If you have both it will first equip the axe.

# 1.1.3
Fixed: Pipette not working for stumps

# 1.1.2

Added: Pipette for "Guck sacks"

# 1.1.1
Fixed: Pipette for pickaxe not working with scrap iron piles

# 1.1.0
Added pipette for axe and pickaxe
Added hotkey for Hammer

# 1.0.0
Initial release